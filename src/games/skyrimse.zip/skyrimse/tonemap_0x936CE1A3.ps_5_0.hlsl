#include "./shared.h"

// ---- Created with 3Dmigoto v1.3.16 on Sat May 18 02:41:57 2024
Texture2D<float4> t2 : register(t2);  // adaptation

Texture2D<float4> t1 : register(t1);  // color

Texture2D<float4> t0 : register(t0);  // bloom

SamplerState s2_s : register(s2);  // adaptation

SamplerState s1_s : register(s1);  // color

SamplerState s0_s : register(s0);  // bloom

cbuffer cb2 : register(b2) {
  float4 cb2[5];
}

cbuffer cb12 : register(b12) {
  float4 cb12[45];
}

// 3Dmigoto declarations
#define cmp -

void main(
    float4 v0: SV_POSITION0,
    float2 v1: TEXCOORD0,
    out float4 o0: SV_Target0) {
  float4 r0, r1, r2, r3;
  uint4 bitmask, uiDest;
  float4 fDest;
  r0.xy = cb12[43].xy * v1.xy;
  r0.xy = max(float2(0, 0), r0.xy);
  r1.x = min(cb12[44].z, r0.x);
  r1.y = min(cb12[43].y, r0.y);
  r0.xyz = t1.Sample(s1_s, r1.xy).xyz;

  // debug: untonemapped
 // o0.w = 1;
 // o0.xyz = r0.xyz;
  //o0.xyz = pow(o0.xyz, 2.2);      // gamma decode
  // o0.xyz = pow(o0.xyz, 1 / 2.2);  // gamma encode
 // return;
  r0.w = cmp(0.5 < cb2[0].x);
  if (r0.w != 0) {
    r1.xyz = t0.Sample(s0_s, r1.xy).xyz;
  } else {
    r1.xyz = t0.Sample(s0_s, v1.xy).xyz;
  }

  r2.xy = t2.Sample(s2_s, v1.xy).xy;

  // Eye adaptation - HARDCODED, no shader_injection
  float lum = dot(float3(0.212500006, 0.715399981, 0.0720999986), r0.xyz);
  lum = max(9.99999975e-006, lum);
  float lumAdjusted = lum * r2.y / r2.x;

  // Auto exposure: hardcoded to 1.0 (fully on)
  r0.xyz = r0.xyz * lumAdjusted / lum;

//   const float3 untonemapped = r0.xyz;
// 
//   float lumMapped = lumAdjusted * (lumAdjusted * cb2[2].y + 1.0) / (lumAdjusted + 1.0);
// 
//   // Hardcoded: skip tone_map_type branch, just use vanilla Reinhard
//   r0.xyz = r0.xyz * lumMapped / lumAdjusted;

  // Bloom: hardcoded to 1.0
  // r0.xyz = (r1.xyz * saturate(cb2[2].x - lumMapped)) * 1.0 + r0.xyz;
  const float bloomStrength = 1;
  r0.xyz = (r1.xyz * saturate(cb2[2].x - renodx::color::y::from::BT709(r0.xyz))) * bloomStrength + r0.xyz; //TODO: does bloom look good going before tonemap?

  

  // Clean color to BT709 //TODO: there is no WCG, this is BT709, right?
  r0.xyz = max(0, r0.xyz);

  // Linearize //TODO: Musa said it's needed right?
  //r0.xyz = pow(r0.xyz, 2.2); // gamma decode

  // // Manual ToneMapPass(): Gamma Correction
  // if (RENODX_GAMMA_CORRECTION == 1) {
  //   r0.xyz = renodx::color::correct::Gamma(r0.xyz, false, 2.2);
  // }else if (RENODX_GAMMA_CORRECTION == 2) {
  //    r0.xyz = renodx::color::correct::Gamma(r0.xyz, false, 2.4);
  //  }

  // //Manual ToneMapPass(): HDR Tonemap by Luminance
  // float peak = RENODX_PEAK_WHITE_NITS / RENODX_DIFFUSE_WHITE_NITS;
  // float whiteClip = 6000.f / RENODX_DIFFUSE_WHITE_NITS; //TODO: change max expected.
  // r0.xyz = renodx::tonemap::HermiteSplineLuminanceRolloff(r0.xyz, peak, whiteClip);
  renodx::draw::Config config = renodx::draw::BuildConfig();
  config.reno_drt_tone_map_method = renodx::tonemap::renodrt::config::tone_map_method::HERMITE_SPLINE;
  // Linearize
  r0.xyz = renodx::color::gamma::Decode(r0.xyz);
  // ToneMapPass()
  r0.xyz = renodx::draw::ToneMapPass(r0.xyz);
  // Gamma
  r0.xyz = renodx::color::gamma::Encode(r0.xyz);

  // Color grading (in gamma space)
  r1.x = dot(r0.xyz, float3(0.212500006, 0.715399981, 0.0720999986));
  r0.w = 1;
  float3 outputColor = r0.xyz;
  r0.xyzw = -r1.xxxx + r0.xyzw;
  r0.xyzw = cb2[3].xxxx * r0.xyzw + r1.xxxx;
  r1.xyzw = r1.xxxx * cb2[4].xyzw + -r0.xyzw;
  r0.xyzw = cb2[4].wwww * r1.xyzw + r0.xyzw;
  r0.xyzw = cb2[3].wwww * r0.xyzw + -r2.xxxx;
  r0.xyzw = cb2[3].zzzz * r0.xyzw + r2.xxxx;
  r0.xyz = lerp(outputColor, r0.xyz, 1.0);  // strength

  // Linearize
  r0.xyz = renodx::color::gamma::DecodeSafe(r0.xyz);  
  // safe, since colorgrade can go WCG maybe
  //Encode to BT2020 to preserve WCG before TAA
  r0.xyz = renodx::color::bt2020::from::BT709(r0.xyz);
  r0.xyz = max(0, r0.xyz);
  // RenderIntermediatePass()
  r0.xyz = renodx::draw::RenderIntermediatePass(r0.xyz);  // This will auto handle UI Brightness and Gamma Encode for SwapChain

  o0.xyz = r0.xyz;
  o0.w = r0.w;
  return;
}